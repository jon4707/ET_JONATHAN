productos = {'C-123': ['HP', 15.6, '8GB', 'DD', '1T', 'Intel Core i5', 'Nvidia GTX1050'],
        'C-111': ['lenovo', 14, '4GB', 'SSD', '512GB', 'Intel Core i5', 'Nvidia GTX1050'],
        'C-234': ['Asus', 14, '16GB', 'SSD', '256GB', 'Intel Core i7', 'Nvidia RTX2080Ti'],
        'C-456': ['HP', 15.6, '8GB', 'DD', '1T', 'Intel Core i3', 'integrada'],
        'C-1222': ['Asus', 15.6, '8GB', 'DD', '1T', 'Intel Core i7', 'Nvidia GTX1050'],
        'C-477': ['lenovo', 14, '6GB', 'DD', '1T', 'AMD Ryzen 5', 'integrada'],
        'C-334': ['lenovo', 15.6, '8GB', 'DD', '1T', 'AMD Ryzen 7', 'Nvidia GTX1050'],
        'C-2906': ['Dell', 15.6, '8GB', 'DD', '1T', 'AMD Ryzen 3', 'Nvidia GTX1050']
        }

stock = {'C-123': [387990,10],
        'C-111': [327990,4], 
        'C-234': [424990,1],
        'C-456': [664990,21], 
        'C-477': [290890,32], 
        'C-334': [444990,7],
        'C-1222': [749990,2], 
        'C-2906': [349990,1]
        }
def stock_marca(lst_productos: dict, lst_stock: dict, marca_buscada: str)->int:
        for marcas in lst_productos.values(0):
                if marca_buscada in marcas:
                        lst_productos.keys()==lst_stock.keys()
                        if lst_stock.values[1]>0:
                                return lst_stock.values[1]
                        else:
                                return 0
                
def busqueda_precio(lst_productos: dict,lst_stock: dict,p_min:int, p_max: int)->None:
        resultado=False
        for precio in lst_stock.values(0):
                if p_min<=precio<=p_max:
                        lst_productos.keys()==lst_stock.keys()
                        codigo=lst_productos.keys()
                        marca=lst_productos.values(0)
                        tamaño=lst_productos.values(1)
                        memoria_RAM=lst_productos.values(2)
                        almacenamiento=lst_productos.values(3)
                        procesador=lst_productos.values(4)
                        tarjeta_grafica=lst_productos.values(5)
                        print(f"El codigo es: {codigo},\nLa marca es: {marca},\nEl tamaño es: {tamaño},")
                        print(f"La memoria RAM es: {memoria_RAM},\nEl almacenamiento es de: {almacenamiento},")
                        print(f"El procesador es de {procesador},\ny La tarjeta grafica es: {tarjeta_grafica}")
                        resultado=True
                if not resultado:
                        print("El producto que buscas no se encuentra disponible")
def actualizar_precio(lst_stock: dict, codigo: str, nuevo_precio:int)->bool:
        if codigo in lst_stock.keys and nuevo_precio>0:
                nuevo_precio=lst_stock.values(0)
                return True
        return False
while True:
        print("Bienvenido a nuestra tienda tecnologica...")
        print("En que lo podemos ayudar...")
        print("1. Consultar stok de marcas especificas.")
        print("2. Buscar productos por rago de precio.")
        print("3. Actualizar precio de algun producto.")
        print("4. Salir del programa...")
        try:
                opc=int(input("Ingrese una opcion por favor (1,2,3 o 4): "))
        except ValueError:
                print("Opcion no valida, intentelo nuevamente.")
        else:
                if opc==1:
                        marca=input("Que marca deseas buscar?  ")
                        print(f"Existen estos computadores: {stock}")
                elif opc==2:
                        try:
                                p_minn=int(input("ingrese el rango minimo de valores de los PC"))
                                p_maxx=int(input("Ingrese el rango maximo de los valores de los PC"))
                        except ValueError:
                                print("ingrese rangos validos...")
                        else:
                                if p_minn>0 and p_maxx>p_minn:
                                        print("Buscando productos")
                elif opc==4:
                        print("SALIENDO DE LA TIENDA...")
                        break